import { GoogleGenAI } from "@google/genai";

export async function generateControlNarrative(controlId: string, controlTitle: string, existingNarrative: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    
    const prompt = `You are a cybersecurity expert specializing in NIST 800-53 and OSCAL documentation.
I need you to generate or refine a control implementation narrative for a System Security Plan (SSP).

Control ID: ${controlId}
Control Title: ${controlTitle}

${existingNarrative && existingNarrative.trim() !== '<p></p>' ? `Here is the existing narrative that needs to be refined, expanded, or improved:\n${existingNarrative}\n\nPlease improve it, making it more professional, detailed, and aligned with standard security practices.` : `Please generate a comprehensive, professional implementation narrative for this control from scratch. Describe how a modern cloud-native organization might implement this.`}

Return ONLY the narrative text formatted as HTML (using <p>, <ul>, <li>, <strong>, etc. as appropriate for a rich text editor). Do not include markdown code blocks like \`\`\`html. Just the raw HTML.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    let html = response.text || '';
    // Strip markdown code block if the model accidentally included it
    html = html.replace(/^```html\s*/i, '').replace(/\s*```$/i, '');
    
    return html;
  } catch (error) {
    console.error("Error generating narrative:", error);
    throw new Error("Failed to generate narrative. Please check your API key and try again.");
  }
}
