import { create } from 'zustand';
import { initialOscalData } from '../data/mockOscalData';

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

interface OscalStore {
  oscalData: any;
  saveStatus: SaveStatus;
  lastSaved: Date | null;
  isLoading: boolean;
  
  // Actions
  updateSystemChar: (key: string, value: string) => void;
  updateImpactLevel: (objective: string, value: string) => void;
  updateControl: (controlId: string, key: string, value: string) => void;
  updateControlsBulk: (controlIds: string[], updates: { key: string, value: string }[]) => void;
  
  // Async Actions
  fetchOscalData: (systemId: string) => Promise<void>;
  saveOscalData: () => Promise<void>;
}

// Helper to debounce saves
let saveTimeout: any = null;

export const useOscalStore = create<OscalStore>((set, get) => ({
  oscalData: initialOscalData,
  saveStatus: 'idle',
  lastSaved: null,
  isLoading: false,
  
  fetchOscalData: async (systemId: string) => {
    set({ isLoading: true });
    try {
      // MOCK: In a real app, this would be:
      // const res = await fetch(`/api/systems/${systemId}/oscal`);
      // const data = await res.json();
      
      // Simulating network delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // We'll just use the mock data for now, but pretend we fetched it
      set({ oscalData: initialOscalData, isLoading: false, saveStatus: 'saved', lastSaved: new Date() });
    } catch (error) {
      console.error("Failed to fetch OSCAL data", error);
      set({ isLoading: false, saveStatus: 'error' });
    }
  },

  saveOscalData: async () => {
    set({ saveStatus: 'saving' });
    try {
      // MOCK: In a real app, this would be:
      // await fetch(`/api/systems/${systemId}/oscal`, { method: 'PUT', body: JSON.stringify(get().oscalData) });
      
      // Simulating network delay
      await new Promise(resolve => setTimeout(resolve, 600));
      
      set({ saveStatus: 'saved', lastSaved: new Date() });
    } catch (error) {
      console.error("Failed to save OSCAL data", error);
      set({ saveStatus: 'error' });
    }
  },
  
  updateSystemChar: (key, value) => {
    set((state) => {
      const newData = JSON.parse(JSON.stringify(state.oscalData));
      newData['system-security-plan']['system-characteristics'][key] = value;
      return { oscalData: newData, saveStatus: 'saving' };
    });
    
    // Trigger auto-save
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => get().saveOscalData(), 1500);
  },
  
  updateImpactLevel: (objective, value) => {
    set((state) => {
      const newData = JSON.parse(JSON.stringify(state.oscalData));
      newData['system-security-plan']['system-characteristics']['security-impact-level'][`security-objective-${objective}`] = value.toLowerCase();
      return { oscalData: newData, saveStatus: 'saving' };
    });
    
    // Trigger auto-save
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => get().saveOscalData(), 1500);
  },
  
  updateControl: (controlId, key, value) => {
    set((state) => {
      const newData = JSON.parse(JSON.stringify(state.oscalData));
      const reqs = newData['system-security-plan']['control-implementation']['implemented-requirements'];
      const reqIndex = reqs.findIndex((r: any) => r['control-id'] === controlId);
      
      if (reqIndex >= 0) {
        if (key === 'description') {
          reqs[reqIndex].description = value;
        } else if (key === 'implementation-status' || key === 'control-origination') {
          const propIndex = reqs[reqIndex].prop.findIndex((p: any) => p.name === key);
          if (propIndex >= 0) {
            reqs[reqIndex].prop[propIndex].value = value;
          } else {
            reqs[reqIndex].prop.push({ name: key, value: value });
          }
        }
      }
      return { oscalData: newData, saveStatus: 'saving' };
    });
    
    // Trigger auto-save
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => get().saveOscalData(), 1500);
  },

  updateControlsBulk: (controlIds, updates) => {
    set((state) => {
      const newData = JSON.parse(JSON.stringify(state.oscalData));
      const reqs = newData['system-security-plan']['control-implementation']['implemented-requirements'];
      
      controlIds.forEach(controlId => {
        const reqIndex = reqs.findIndex((r: any) => r['control-id'] === controlId);
        if (reqIndex >= 0) {
          updates.forEach(({ key, value }) => {
            if (key === 'description') {
              reqs[reqIndex].description = value;
            } else if (key === 'implementation-status' || key === 'control-origination') {
              const propIndex = reqs[reqIndex].prop.findIndex((p: any) => p.name === key);
              if (propIndex >= 0) {
                reqs[reqIndex].prop[propIndex].value = value;
              } else {
                reqs[reqIndex].prop.push({ name: key, value: value });
              }
            }
          });
        }
      });
      
      return { oscalData: newData, saveStatus: 'saving' };
    });
    
    // Trigger auto-save
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => get().saveOscalData(), 1500);
  }
}));
