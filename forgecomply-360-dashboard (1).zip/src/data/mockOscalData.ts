export const initialOscalData = {
  "system-security-plan": {
    "metadata": {
      "title": "ForgeComply Enterprise GRC",
      "oscal-version": "1.1.2",
      "version": "1.0"
    },
    "system-characteristics": {
      "system-name": "ForgeComply Enterprise GRC",
      "system-name-short": "FC-GRC",
      "description": "ForgeComply Enterprise GRC is a multi-tenant compliance management platform built on Cloudflare's edge infrastructure. It provides continuous monitoring, control mapping, and automated reporting for federal and commercial compliance frameworks including FedRAMP, SOC 2, and CMMC 2.0.",
      "security-sensitivity-level": "moderate",
      "security-impact-level": {
        "security-objective-confidentiality": "moderate",
        "security-objective-integrity": "moderate",
        "security-objective-availability": "moderate"
      }
    },
    "control-implementation": {
      "description": "This section describes how the system implements the applicable security controls.",
      "implemented-requirements": [
        {
          "control-id": "ac-1",
          "title": "Access Control Policy and Procedures",
          "description": "<p>The organization develops, documents, and disseminates an access control policy that addresses purpose, scope, roles, responsibilities, management commitment, coordination among organizational entities, and compliance.</p>",
          "prop": [
            { "name": "implementation-status", "value": "implemented" },
            { "name": "control-origination", "value": "sp-corporate" }
          ]
        },
        {
          "control-id": "ac-2",
          "title": "Account Management",
          "description": "<p>The organization defines and documents the types of accounts allowed and specifically prohibits the use of shared or group accounts. The system automatically disables inactive accounts after 35 days.</p>",
          "prop": [
            { "name": "implementation-status", "value": "partial" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ac-3",
          "title": "Access Enforcement",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ac-4",
          "title": "Information Flow Enforcement",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ac-5",
          "title": "Separation of Duties",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ac-6",
          "title": "Least Privilege",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "at-1",
          "title": "Security Awareness and Training Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-corporate" }
          ]
        },
        {
          "control-id": "at-2",
          "title": "Security Awareness Training",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-corporate" }
          ]
        },
        {
          "control-id": "au-1",
          "title": "Audit and Accountability Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "au-2",
          "title": "Audit Events",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "au-3",
          "title": "Content of Audit Records",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "cm-1",
          "title": "Configuration Management Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "cm-2",
          "title": "Baseline Configuration",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "cm-8",
          "title": "System Component Inventory",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ia-1",
          "title": "Identification and Authentication Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ia-2",
          "title": "Identification and Authentication (Organizational Users)",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ia-5",
          "title": "Authenticator Management",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "ir-1",
          "title": "Incident Response Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-corporate" }
          ]
        },
        {
          "control-id": "ir-4",
          "title": "Incident Handling",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-corporate" }
          ]
        },
        {
          "control-id": "sc-1",
          "title": "System and Communications Protection Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "sc-7",
          "title": "Boundary Protection",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "sc-8",
          "title": "Transmission Confidentiality and Integrity",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "si-1",
          "title": "System and Information Integrity Policy and Procedures",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "si-2",
          "title": "Flaw Remediation",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "si-3",
          "title": "Malicious Code Protection",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        },
        {
          "control-id": "si-4",
          "title": "Information System Monitoring",
          "description": "",
          "prop": [
            { "name": "implementation-status", "value": "planned" },
            { "name": "control-origination", "value": "sp-system" }
          ]
        }
      ]
    }
  }
};
