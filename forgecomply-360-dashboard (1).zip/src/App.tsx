import React from 'react';
import { BrowserRouter, Routes, Route, Link, useParams } from 'react-router-dom';
import { ReporterLayout } from './components/ReporterLayout';
import { Shield, FileText, LayoutDashboard } from 'lucide-react';

// A mock Dashboard to show how the user navigates TO the Reporter
function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50 p-8">
      <header className="mb-8 flex items-center space-x-3">
        <Shield className="w-8 h-8 text-indigo-600" />
        <h1 className="text-2xl font-bold text-slate-900">ForgeComply 360 Dashboard</h1>
      </header>
      
      <div className="max-w-4xl bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <LayoutDashboard className="w-5 h-5 mr-2 text-slate-500" />
          Your Systems
        </h2>
        
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 font-medium text-slate-600">System Name</th>
                <th className="px-4 py-3 font-medium text-slate-600">Framework</th>
                <th className="px-4 py-3 font-medium text-slate-600">Status</th>
                <th className="px-4 py-3 font-medium text-slate-600 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              <tr className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 font-medium text-slate-900">Enterprise Cloud Platform</td>
                <td className="px-4 py-3 text-slate-600">FedRAMP Moderate</td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                    In Progress
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <Link 
                    to="/systems/sys-123/reporter"
                    className="inline-flex items-center px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium rounded-md transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 mr-1.5" />
                    Open SSP Reporter
                  </Link>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// A wrapper to extract the systemId from the URL and pass it to the Layout
function ReporterRouteWrapper() {
  const { systemId } = useParams();
  // In a real app, you might pass systemId as a prop or let the Layout read it from the URL
  return <ReporterLayout systemId={systemId} />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/systems/:systemId/reporter" element={<ReporterRouteWrapper />} />
      </Routes>
    </BrowserRouter>
  );
}

