import React, { useState, useEffect } from 'react';
import { ReporterSidebar } from './ReporterSidebar';
import { ReporterEditor } from './ReporterEditor';
import { ReporterAssistant } from './ReporterAssistant';
import { Cloud, Download, Shield, FileJson, X, ArrowLeft, CheckCircle2, Loader2, AlertCircle } from 'lucide-react';
import { useOscalStore } from '../store/oscalStore';
import { Link } from 'react-router-dom';
import { generateSspPdf } from '../utils/pdfGenerator';

interface ReporterLayoutProps {
  systemId?: string;
}

export function ReporterLayout({ systemId }: ReporterLayoutProps) {
  const [activeSection, setActiveSection] = useState('system-info');
  const [rightPaneTab, setRightPaneTab] = useState<'ai' | 'validation'>('ai');
  const [showJsonModal, setShowJsonModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  
  const { oscalData, saveStatus, lastSaved, fetchOscalData } = useOscalStore();

  // Fetch data when the component mounts or systemId changes
  useEffect(() => {
    if (systemId) {
      fetchOscalData(systemId);
    }
  }, [systemId, fetchOscalData]);

  const handleExportPdf = async () => {
    setIsExporting(true);
    try {
      await generateSspPdf(oscalData);
    } catch (error) {
      console.error("Failed to generate PDF", error);
      alert("Failed to generate PDF. See console for details.");
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="h-screen w-full bg-[#f8fafc] flex flex-col overflow-hidden font-sans relative">
      {/* Header */}
      <header className="h-14 bg-forge-navy text-white flex items-center justify-between px-4 shrink-0 z-10 shadow-sm">
        <div className="flex items-center space-x-3">
          <Link to="/" className="p-1.5 hover:bg-forge-navy-700 rounded-md transition-colors text-forge-navy-300 hover:text-white mr-1">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <Shield className="w-5 h-5 text-forge-green" />
          <span className="font-semibold tracking-wide">ForgeComply 360 Reporter</span>
          <div className="h-4 w-px bg-forge-navy-700 mx-2"></div>
          <div className="flex items-center text-xs font-medium bg-forge-navy-800 px-2 py-1 rounded-md text-forge-navy-200 border border-forge-navy-700">
            <Cloud className="w-3 h-3 mr-1.5 text-forge-green" />
            Connected Mode
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          {/* Save Status Indicator */}
          <div className="flex items-center text-xs mr-2">
            {saveStatus === 'saving' && (
              <span className="flex items-center text-amber-400">
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                Saving to Cloudflare...
              </span>
            )}
            {saveStatus === 'saved' && (
              <span className="flex items-center text-forge-navy-300">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
                Saved {lastSaved ? lastSaved.toLocaleTimeString() : ''}
              </span>
            )}
            {saveStatus === 'error' && (
              <span className="flex items-center text-red-400">
                <AlertCircle className="w-3.5 h-3.5 mr-1.5" />
                Save Failed
              </span>
            )}
          </div>

          <button 
            onClick={() => setShowJsonModal(true)}
            className="flex items-center px-3 py-1.5 text-sm font-medium bg-forge-navy-800 hover:bg-forge-navy-700 rounded-md transition-colors border border-forge-navy-700"
          >
            <FileJson className="w-4 h-4 mr-2 text-forge-navy-300" />
            OSCAL JSON
          </button>
          <button 
            onClick={handleExportPdf}
            disabled={isExporting}
            className="flex items-center px-3 py-1.5 text-sm font-medium bg-forge-green text-forge-navy-950 hover:bg-forge-green-400 rounded-md transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isExporting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Download className="w-4 h-4 mr-2" />
            )}
            {isExporting ? 'Generating...' : 'Export SSP'}
          </button>
        </div>
      </header>

      {/* Three-Pane Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Pane: Navigation */}
        <ReporterSidebar activeSection={activeSection} onSelectSection={setActiveSection} />
        
        {/* Center Pane: Editor */}
        <ReporterEditor activeSection={activeSection} />
        
        {/* Right Pane: AI & Validation */}
        <ReporterAssistant activeTab={rightPaneTab} onTabChange={setRightPaneTab} />
      </div>

      {/* JSON Viewer Modal */}
      {showJsonModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-8">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-full max-h-[80vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h2 className="text-lg font-semibold text-forge-navy flex items-center">
                <FileJson className="w-5 h-5 mr-2 text-indigo-500" />
                Live OSCAL 1.1.2 JSON
              </h2>
              <button onClick={() => setShowJsonModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6 bg-slate-900">
              <pre className="text-emerald-400 font-mono text-sm leading-relaxed">
                {JSON.stringify(oscalData, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
