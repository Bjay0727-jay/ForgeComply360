import React, { useMemo } from 'react';
import { CheckCircle2, Circle, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';
import { useOscalStore } from '../store/oscalStore';

export function ReporterSidebar({ activeSection, onSelectSection }: { activeSection: string, onSelectSection: (id: string) => void }) {
  const oscalData = useOscalStore(state => state.oscalData);

  const sysInfoProgress = useMemo(() => {
    const chars = oscalData['system-security-plan']['system-characteristics'];
    const requiredFields = ['system-name', 'system-name-short', 'description'];
    let filled = 0;
    requiredFields.forEach(field => {
      if (chars[field] && chars[field].trim() !== '') {
        filled++;
      }
    });
    return Math.round((filled / requiredFields.length) * 100);
  }, [oscalData]);

  const controlsProgress = useMemo(() => {
    const reqs = oscalData['system-security-plan']['control-implementation']['implemented-requirements'];
    const total = reqs.length;
    const completed = reqs.filter((r: any) => {
      const statusProp = r.prop.find((p: any) => p.name === 'implementation-status');
      const isStatusComplete = statusProp && statusProp.value !== 'planned';
      const hasNarrative = r.description && r.description.trim() !== '' && r.description !== '<p></p>';
      
      if (statusProp?.value === 'not-applicable') return true;
      return isStatusComplete && hasNarrative;
    }).length;
    
    return {
      completed,
      total,
      percentage: total === 0 ? 0 : Math.round((completed / total) * 100)
    };
  }, [oscalData]);

  const sections = [
    { id: 'system-info', title: '1. System Information', progress: sysInfoProgress },
    { id: 'fips-199', title: '2. FIPS 199 Categorization', progress: 100 },
    { id: 'system-env', title: '3. System Environment', progress: 60 },
    { id: 'roles', title: '4. Roles & Responsibilities', progress: 0 },
    { id: 'network', title: '5. Network Architecture', progress: 0 },
    { id: 'data-flow', title: '6. Data Flow', progress: 0 },
    { id: 'ports', title: '7. Ports, Protocols & Services', progress: 0 },
    { id: 'controls', title: '15. Minimum Security Controls', progress: controlsProgress.percentage },
    { id: 'all-controls', title: 'All Controls', progress: controlsProgress.percentage },
  ];

  // Calculate overall progress based on the mocked sections
  const totalProgress = Math.round(sections.reduce((acc, sec) => acc + sec.progress, 0) / sections.length);

  return (
    <div className="w-72 bg-white border-r border-slate-200 flex flex-col shrink-0 overflow-y-auto">
      <div className="p-4 border-b border-slate-100 sticky top-0 bg-white/95 backdrop-blur z-10">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">SSP Sections</h2>
        <div className="w-full bg-slate-100 rounded-full h-1.5 mt-3">
          <div className="bg-forge-green h-1.5 rounded-full transition-all duration-500" style={{ width: `${totalProgress}%` }}></div>
        </div>
        <p className="text-xs text-slate-500 mt-2 font-medium">{totalProgress}% Complete</p>
      </div>
      
      <nav className="flex-1 py-2">
        {sections.map((section) => {
          const isActive = activeSection === section.id;
          const isComplete = section.progress === 100;
          const isPartial = section.progress > 0 && section.progress < 100;
          
          return (
            <button
              key={section.id}
              onClick={() => onSelectSection(section.id)}
              className={cn(
                "w-full flex items-center px-4 py-3 text-sm text-left transition-colors border-l-2",
                isActive 
                  ? "bg-forge-navy-50 border-forge-navy text-forge-navy font-medium" 
                  : "border-transparent text-slate-600 hover:bg-slate-50"
              )}
            >
              {isComplete ? (
                <CheckCircle2 className="w-4 h-4 mr-3 text-forge-green shrink-0" />
              ) : isPartial ? (
                <div className="w-4 h-4 mr-3 shrink-0 relative flex items-center justify-center">
                  <Circle className="w-4 h-4 text-slate-200 absolute" />
                  <svg className="w-4 h-4 transform -rotate-90 absolute text-forge-green" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray={`${section.progress * 0.6} 100`} />
                  </svg>
                </div>
              ) : (
                <Circle className="w-4 h-4 mr-3 text-slate-200 shrink-0" />
              )}
              
              <span className="truncate flex-1">{section.title}</span>
              
              {(section.id === 'controls' || section.id === 'all-controls') && (
                <span className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-full font-medium ml-2 shrink-0",
                  isComplete ? "bg-forge-green-100 text-forge-green-700" : "bg-slate-100 text-slate-500"
                )}>
                  {controlsProgress.completed}/{controlsProgress.total}
                </span>
              )}

              {section.id === 'system-info' && (
                <span className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-full font-medium ml-2 shrink-0",
                  isComplete ? "bg-forge-green-100 text-forge-green-700" : "bg-slate-100 text-slate-500"
                )}>
                  {sysInfoProgress}%
                </span>
              )}
              
              {isActive && section.id !== 'controls' && section.id !== 'all-controls' && section.id !== 'system-info' && (
                <ChevronRight className="w-4 h-4 text-forge-navy-400 shrink-0 ml-2" />
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
