import React, { useEffect } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Bold, Italic, Strikethrough, List, ListOrdered, Code, Quote, Heading1, Heading2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
}

const MenuBar = ({ editor }: { editor: any }) => {
  if (!editor) {
    return null;
  }

  return (
    <div className="flex flex-wrap items-center gap-1 border-b border-slate-200 bg-slate-50 p-2 rounded-t-md">
      <button
        onClick={() => editor.chain().focus().toggleBold().run()}
        disabled={!editor.can().chain().focus().toggleBold().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('bold') && "bg-slate-200 text-forge-navy")}
        title="Bold"
      >
        <Bold className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleItalic().run()}
        disabled={!editor.can().chain().focus().toggleItalic().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('italic') && "bg-slate-200 text-forge-navy")}
        title="Italic"
      >
        <Italic className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleStrike().run()}
        disabled={!editor.can().chain().focus().toggleStrike().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('strike') && "bg-slate-200 text-forge-navy")}
        title="Strikethrough"
      >
        <Strikethrough className="w-4 h-4" />
      </button>
      
      <div className="w-px h-4 bg-slate-300 mx-1"></div>

      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('heading', { level: 1 }) && "bg-slate-200 text-forge-navy")}
        title="Heading 1"
      >
        <Heading1 className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('heading', { level: 2 }) && "bg-slate-200 text-forge-navy")}
        title="Heading 2"
      >
        <Heading2 className="w-4 h-4" />
      </button>
      
      <div className="w-px h-4 bg-slate-300 mx-1"></div>
      
      <button
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('bulletList') && "bg-slate-200 text-forge-navy")}
        title="Bullet List"
      >
        <List className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('orderedList') && "bg-slate-200 text-forge-navy")}
        title="Ordered List"
      >
        <ListOrdered className="w-4 h-4" />
      </button>
      
      <div className="w-px h-4 bg-slate-300 mx-1"></div>
      
      <button
        onClick={() => editor.chain().focus().toggleCodeBlock().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('codeBlock') && "bg-slate-200 text-forge-navy")}
        title="Code Block"
      >
        <Code className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleBlockquote().run()}
        className={cn("p-1.5 rounded hover:bg-slate-200 text-slate-600 transition-colors", editor.isActive('blockquote') && "bg-slate-200 text-forge-navy")}
        title="Blockquote"
      >
        <Quote className="w-4 h-4" />
      </button>
    </div>
  );
};

export function RichTextEditor({ value, onChange }: RichTextEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
    ],
    content: value,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose-base max-w-none focus:outline-none min-h-[300px] p-4 bg-white rounded-b-md',
      },
    },
  });

  // Update editor content when value prop changes externally (e.g., selecting a different control)
  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value);
    }
  }, [value, editor]);

  return (
    <div className="border border-slate-300 rounded-md shadow-sm overflow-hidden focus-within:ring-2 focus-within:ring-forge-navy focus-within:border-forge-navy transition-shadow">
      <MenuBar editor={editor} />
      <EditorContent editor={editor} />
    </div>
  );
}
