import React from 'react';
import { Shield, LayoutDashboard, Server, CheckSquare, AlertTriangle, FileText, Settings, LogOut } from 'lucide-react';
import { cn } from '../lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', active: true },
  { icon: Server, label: 'Systems & Assets' },
  { icon: CheckSquare, label: 'Compliance & Controls' },
  { icon: AlertTriangle, label: 'POA&M' },
  { icon: FileText, label: 'Reports' },
  { icon: Settings, label: 'Settings' },
];

export function Sidebar() {
  return (
    <div className="w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800">
      <div className="h-16 flex items-center px-6 border-b border-slate-800">
        <Shield className="w-6 h-6 text-indigo-400 mr-3" />
        <span className="font-bold text-white text-lg tracking-tight">ForgeComply 360</span>
      </div>
      
      <div className="flex-1 py-6 px-3 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={cn(
              "w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors",
              item.active 
                ? "bg-indigo-500/10 text-indigo-400" 
                : "hover:bg-slate-800 hover:text-white"
            )}
          >
            <item.icon className={cn("w-5 h-5 mr-3", item.active ? "text-indigo-400" : "text-slate-400")} />
            {item.label}
          </button>
        ))}
      </div>

      <div className="p-4 border-t border-slate-800">
        <button className="w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-slate-800 hover:text-white transition-colors">
          <LogOut className="w-5 h-5 mr-3 text-slate-400" />
          Sign Out
        </button>
      </div>
    </div>
  );
}
