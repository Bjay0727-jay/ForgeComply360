import React, { useState } from 'react';
import { Save, Search, CheckCircle2, Circle, AlertCircle, Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { RichTextEditor } from './RichTextEditor';
import { useOscalStore } from '../store/oscalStore';
import { generateControlNarrative } from '../services/geminiService';

interface ReporterEditorProps {
  activeSection: string;
}

function SystemInfoEditor() {
  const oscalData = useOscalStore(state => state.oscalData);
  const updateSystemChar = useOscalStore(state => state.updateSystemChar);
  const updateImpactLevel = useOscalStore(state => state.updateImpactLevel);

  const sysChars = oscalData['system-security-plan']['system-characteristics'];
  const impactLevel = sysChars['security-impact-level'];
  const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

  return (
    <div className="max-w-3xl mx-auto space-y-8 p-8">
      {/* Form Group 1 */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-forge-navy uppercase tracking-wider border-b border-slate-200 pb-2">1.1 System Identification</h3>
        
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">System Name <span className="text-red-500">*</span></label>
            <input 
              type="text" 
              value={sysChars['system-name']}
              onChange={(e) => updateSystemChar('system-name', e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">System Abbreviation <span className="text-red-500">*</span></label>
            <input 
              type="text" 
              value={sysChars['system-name-short']}
              onChange={(e) => updateSystemChar('system-name-short', e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-medium text-slate-700">System Description <span className="text-red-500">*</span></label>
          <p className="text-xs text-slate-500 mb-2">Provide a general description of the system, including its purpose and the business functions it supports.</p>
          <textarea 
            rows={5}
            value={sysChars['description']}
            onChange={(e) => updateSystemChar('description', e.target.value)}
            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
          />
        </div>
      </div>

      {/* Form Group 2 */}
      <div className="space-y-4 pt-4">
        <h3 className="text-sm font-bold text-forge-navy uppercase tracking-wider border-b border-slate-200 pb-2">1.2 System Categorization</h3>
        
        <div className="grid grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Confidentiality</label>
            <select 
              value={capitalize(impactLevel['security-objective-confidentiality'])}
              onChange={(e) => updateImpactLevel('confidentiality', e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            >
              <option value="Low">Low</option>
              <option value="Moderate">Moderate</option>
              <option value="High">High</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Integrity</label>
            <select 
              value={capitalize(impactLevel['security-objective-integrity'])}
              onChange={(e) => updateImpactLevel('integrity', e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            >
              <option value="Low">Low</option>
              <option value="Moderate">Moderate</option>
              <option value="High">High</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Availability</label>
            <select 
              value={capitalize(impactLevel['security-objective-availability'])}
              onChange={(e) => updateImpactLevel('availability', e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            >
              <option value="Low">Low</option>
              <option value="Moderate">Moderate</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

function ControlsEditor() {
  const oscalData = useOscalStore(state => state.oscalData);
  const updateControl = useOscalStore(state => state.updateControl);

  const reqs = oscalData['system-security-plan']['control-implementation']['implemented-requirements'];
  const [selectedControlId, setSelectedControlId] = useState(reqs[0]['control-id']);
  const [searchQuery, setSearchQuery] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState('');

  const selectedReq = reqs.find((r: any) => r['control-id'] === selectedControlId);
  
  const getPropValue = (req: any, propName: string) => {
    const prop = req.prop.find((p: any) => p.name === propName);
    return prop ? prop.value : '';
  };

  const handleGenerateNarrative = async () => {
    if (!selectedReq) return;
    
    setIsGenerating(true);
    setGenerateError('');
    try {
      const newNarrative = await generateControlNarrative(
        selectedReq['control-id'],
        selectedReq.title,
        selectedReq.description
      );
      updateControl(selectedReq['control-id'], 'description', newNarrative);
    } catch (error) {
      console.error(error);
      setGenerateError('Failed to generate narrative.');
    } finally {
      setIsGenerating(false);
    }
  };

  const filteredReqs = reqs.filter((r: any) => {
    if (!searchQuery.trim()) return true;
    
    const searchTerms = searchQuery.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    
    const id = r['control-id'].toLowerCase();
    const title = r.title.toLowerCase();
    const status = getPropValue(r, 'implementation-status').toLowerCase();
    const origination = getPropValue(r, 'control-origination').toLowerCase();
    
    // All space-separated terms must match at least one of the fields
    return searchTerms.every(term => 
      id.includes(term) || 
      title.includes(term) || 
      status.includes(term) || 
      origination.includes(term)
    );
  });

  return (
    <div className="flex h-full">
      {/* Controls List (Left Column) */}
      <div className="w-64 border-r border-slate-200 bg-slate-50 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-200">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search controls..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredReqs.map((req: any) => {
            const status = getPropValue(req, 'implementation-status');
            const isComplete = status !== 'planned' && req.description && req.description.trim() !== '' && req.description !== '<p></p>';
            const isActive = selectedControlId === req['control-id'];
            
            return (
              <button
                key={req['control-id']}
                onClick={() => setSelectedControlId(req['control-id'])}
                className={cn(
                  "w-full flex items-center px-3 py-2 text-sm text-left rounded-md transition-colors",
                  isActive 
                    ? "bg-forge-navy text-white" 
                    : "text-slate-700 hover:bg-slate-200"
                )}
              >
                {isComplete ? (
                  <CheckCircle2 className={cn("w-4 h-4 mr-2 shrink-0", isActive ? "text-forge-green" : "text-forge-green")} />
                ) : (
                  <AlertCircle className={cn("w-4 h-4 mr-2 shrink-0", isActive ? "text-amber-300" : "text-amber-500")} />
                )}
                <div className="truncate">
                  <span className="font-bold uppercase mr-2">{req['control-id']}</span>
                  <span className={cn("truncate text-xs", isActive ? "text-forge-navy-100" : "text-slate-500")}>
                    {req.title}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Control Detail (Right Column) */}
      <div className="flex-1 overflow-y-auto p-8 bg-white">
        {selectedReq ? (
          <div className="max-w-3xl mx-auto space-y-6">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded uppercase tracking-wider">
                  {selectedReq['control-id']}
                </span>
                <h2 className="text-xl font-bold text-forge-navy">{selectedReq.title}</h2>
              </div>
              <p className="text-sm text-slate-500 border-b border-slate-200 pb-4">
                Review and document the implementation details for this control to ensure compliance.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-700">Implementation Status</label>
                <select 
                  value={getPropValue(selectedReq, 'implementation-status')}
                  onChange={(e) => updateControl(selectedReq['control-id'], 'implementation-status', e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
                >
                  <option value="implemented">Implemented</option>
                  <option value="partial">Partially Implemented</option>
                  <option value="planned">Planned</option>
                  <option value="alternative">Alternative Implementation</option>
                  <option value="not-applicable">Not Applicable</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-700">Control Origination</label>
                <select 
                  value={getPropValue(selectedReq, 'control-origination')}
                  onChange={(e) => updateControl(selectedReq['control-id'], 'control-origination', e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
                >
                  <option value="sp-corporate">Service Provider Corporate</option>
                  <option value="sp-system">Service Provider System Specific</option>
                  <option value="customer-configured">Customer Configured</option>
                  <option value="shared">Shared</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5 pt-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-slate-700">Control Narrative / Implementation Details</label>
                <button 
                  onClick={handleGenerateNarrative}
                  disabled={isGenerating}
                  className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      Use ForgeML Assistant &rarr;
                    </>
                  )}
                </button>
              </div>
              {generateError && (
                <div className="text-xs text-red-600 mb-2">
                  {generateError}
                </div>
              )}
              <RichTextEditor 
                value={selectedReq.description}
                onChange={(val) => updateControl(selectedReq['control-id'], 'description', val)}
              />
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400">
            Select a control from the list to edit its implementation.
          </div>
        )}
      </div>
    </div>
  );
}

function AllControlsEditor() {
  const oscalData = useOscalStore(state => state.oscalData);
  const updateControl = useOscalStore(state => state.updateControl);
  const updateControlsBulk = useOscalStore(state => state.updateControlsBulk);

  const reqs = oscalData['system-security-plan']['control-implementation']['implemented-requirements'];

  const [selectedControls, setSelectedControls] = useState<string[]>([]);
  const [bulkStatus, setBulkStatus] = useState('');
  const [bulkOrigination, setBulkOrigination] = useState('');

  const getPropValue = (req: any, propName: string) => {
    const prop = req.prop.find((p: any) => p.name === propName);
    return prop ? prop.value : '';
  };

  const toggleControlSelection = (controlId: string) => {
    setSelectedControls(prev => 
      prev.includes(controlId) 
        ? prev.filter(id => id !== controlId)
        : [...prev, controlId]
    );
  };

  const toggleAll = () => {
    if (selectedControls.length === reqs.length) {
      setSelectedControls([]);
    } else {
      setSelectedControls(reqs.map((r: any) => r['control-id']));
    }
  };

  const handleBulkUpdate = () => {
    const updates: { key: string, value: string }[] = [];
    if (bulkStatus) updates.push({ key: 'implementation-status', value: bulkStatus });
    if (bulkOrigination) updates.push({ key: 'control-origination', value: bulkOrigination });

    if (updates.length > 0 && selectedControls.length > 0) {
      updateControlsBulk(selectedControls, updates);
      // Reset bulk form but keep selection, or clear selection? Let's clear selection.
      setSelectedControls([]);
      setBulkStatus('');
      setBulkOrigination('');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-8 bg-slate-50 h-full relative">
      <div className="max-w-4xl mx-auto space-y-8 pb-32">
        <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200">
          <label className="flex items-center space-x-3 cursor-pointer">
            <input 
              type="checkbox" 
              checked={selectedControls.length === reqs.length && reqs.length > 0}
              onChange={toggleAll}
              className="w-4 h-4 text-forge-navy rounded border-slate-300 focus:ring-forge-navy"
            />
            <span className="text-sm font-medium text-slate-700">Select All Controls</span>
          </label>
          <span className="text-sm text-slate-500">{selectedControls.length} selected</span>
        </div>

        {reqs.map((req: any) => {
          const status = getPropValue(req, 'implementation-status');
          const isComplete = status !== 'planned' && req.description && req.description.trim() !== '' && req.description !== '<p></p>';
          const isSelected = selectedControls.includes(req['control-id']);

          return (
            <div key={req['control-id']} className={cn("bg-white rounded-xl shadow-sm border p-6 transition-colors", isComplete ? "border-slate-200" : "border-amber-300 bg-amber-50/10", isSelected ? "ring-2 ring-forge-navy border-transparent" : "")}>
              <div className="flex items-start space-x-4 mb-4">
                <div className="pt-1">
                  <input 
                    type="checkbox" 
                    checked={isSelected}
                    onChange={() => toggleControlSelection(req['control-id'])}
                    className="w-4 h-4 text-forge-navy rounded border-slate-300 focus:ring-forge-navy"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <span className={cn("px-2.5 py-1 text-xs font-bold rounded uppercase tracking-wider", isComplete ? "bg-slate-100 text-slate-700" : "bg-amber-100 text-amber-800")}>
                      {req['control-id']}
                    </span>
                    <h2 className="text-lg font-bold text-forge-navy flex-1">{req.title}</h2>
                    {!isComplete && (
                      <div className="flex items-center text-amber-600 text-xs font-medium bg-amber-50 px-2 py-1 rounded border border-amber-200">
                        <AlertCircle className="w-3.5 h-3.5 mr-1.5" />
                        Action Required
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6 mb-6 pl-8">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Implementation Status</label>
                  <select 
                    value={getPropValue(req, 'implementation-status')}
                    onChange={(e) => updateControl(req['control-id'], 'implementation-status', e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
                  >
                    <option value="implemented">Implemented</option>
                    <option value="partial">Partially Implemented</option>
                    <option value="planned">Planned</option>
                    <option value="alternative">Alternative Implementation</option>
                    <option value="not-applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Control Origination</label>
                  <select 
                    value={getPropValue(req, 'control-origination')}
                    onChange={(e) => updateControl(req['control-id'], 'control-origination', e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
                  >
                    <option value="sp-corporate">Service Provider Corporate</option>
                    <option value="sp-system">Service Provider System Specific</option>
                    <option value="customer-configured">Customer Configured</option>
                    <option value="shared">Shared</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5 pl-8">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Control Narrative / Implementation Details</label>
                </div>
                <RichTextEditor 
                  value={req.description}
                  onChange={(val) => updateControl(req['control-id'], 'description', val)}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Bulk Update Action Bar */}
      {selectedControls.length > 0 && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-white rounded-xl shadow-2xl border border-slate-200 p-4 flex items-center space-x-6 z-50 animate-in slide-in-from-bottom-10">
          <div className="flex items-center space-x-2">
            <span className="flex items-center justify-center w-6 h-6 bg-forge-navy text-white text-xs font-bold rounded-full">
              {selectedControls.length}
            </span>
            <span className="text-sm font-medium text-slate-700">selected</span>
          </div>
          
          <div className="h-8 w-px bg-slate-200"></div>

          <div className="flex items-center space-x-4">
            <select 
              value={bulkStatus}
              onChange={(e) => setBulkStatus(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            >
              <option value="">Update Status...</option>
              <option value="implemented">Implemented</option>
              <option value="partial">Partially Implemented</option>
              <option value="planned">Planned</option>
              <option value="alternative">Alternative Implementation</option>
              <option value="not-applicable">Not Applicable</option>
            </select>

            <select 
              value={bulkOrigination}
              onChange={(e) => setBulkOrigination(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-forge-navy focus:border-forge-navy sm:text-sm"
            >
              <option value="">Update Origination...</option>
              <option value="sp-corporate">Service Provider Corporate</option>
              <option value="sp-system">Service Provider System Specific</option>
              <option value="customer-configured">Customer Configured</option>
              <option value="shared">Shared</option>
            </select>

            <button 
              onClick={handleBulkUpdate}
              disabled={!bulkStatus && !bulkOrigination}
              className="px-4 py-2 bg-forge-navy text-white text-sm font-medium rounded-md hover:bg-forge-navy-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Apply to {selectedControls.length}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function ReporterEditor({ activeSection }: ReporterEditorProps) {
  const getSectionTitle = () => {
    switch (activeSection) {
      case 'system-info': return '1. System Information';
      case 'controls': return '15. Minimum Security Controls';
      case 'all-controls': return 'All Controls (Bulk Edit)';
      default: return 'Section Editor';
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-white min-w-0 relative shadow-[-4px_0_15px_-3px_rgba(0,0,0,0.02)] z-0">
      <div className="h-14 border-b border-slate-200 flex items-center justify-between px-8 shrink-0 bg-white">
        <h1 className="text-lg font-semibold text-forge-navy">
          {getSectionTitle()}
        </h1>
        <div className="flex items-center text-sm text-slate-500">
          <Save className="w-4 h-4 mr-1.5 text-slate-400" />
          Auto-saved
        </div>
      </div>
      
      <div className="flex-1 overflow-hidden">
        {activeSection === 'system-info' && (
          <div className="h-full overflow-y-auto">
            <SystemInfoEditor />
          </div>
        )}
        
        {activeSection === 'controls' && (
          <ControlsEditor />
        )}

        {activeSection === 'all-controls' && (
          <AllControlsEditor />
        )}

        {activeSection !== 'system-info' && activeSection !== 'controls' && activeSection !== 'all-controls' && (
          <div className="flex items-center justify-center h-full text-slate-400 p-8 text-center">
            <p>This section is currently under development. Please use the System Information or Controls sections.</p>
          </div>
        )}
      </div>
    </div>
  );
}
